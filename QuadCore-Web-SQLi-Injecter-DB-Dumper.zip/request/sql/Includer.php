<?php
	require_once 'Curl.php';

	include_once 'Extracteur.php';
	include_once 'Rechercheur.php';

	include_once 'Chaine.php';
	include_once 'Scanneur.php';
	include_once 'Scanneur.php';

	include_once 'Scanneur.php';
	include_once dirname(__FILE__).DS.'sqli_class'.DS.'sqli_colonne.php';
	include_once dirname(__FILE__).DS.'sqli_class'.DS.'sqli_inject.php';
	include_once dirname(__FILE__).DS.'sqli_class'.DS.'sqli_dump.php';
