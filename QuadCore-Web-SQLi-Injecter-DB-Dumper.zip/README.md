# QuadCore-Web-SQLI-Dumper
WEB SQLi Injection and Dumper DATA Hack Tool

I am in no way responsible for the actions you do with this tool. 
Use this tool for prevention or security testing on your own domain.

# URLS SEARCHER
![alt tag](https://raw.githubusercontent.com/quadcoreside/QuadCore-Web-SQLI-Dumper/master/SCREEN%20SQLI%20SCANNER/search.PNG)
# From Vulnerable to Exploitable URL
![alt tag](https://raw.githubusercontent.com/quadcoreside/QuadCore-Web-SQLI-Dumper/master/SCREEN%20SQLI%20SCANNER/analyse.PNG)
# DUMPER DATA
![alt tag](https://raw.githubusercontent.com/quadcoreside/QuadCore-Web-SQLI-Dumper/master/SCREEN%20SQLI%20SCANNER/dumper.PNG)


# By QuadCore ENgineering, MSB, QDMS
