<?php

	require REQU.DS.'sql'.DS.'Includer.php';
	require 'Session.php';
	require 'Dispatcher.php';
	require 'Controller.php';
