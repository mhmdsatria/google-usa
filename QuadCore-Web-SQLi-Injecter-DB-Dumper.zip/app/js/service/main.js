/*
 QUADCORE ENGINEERING MSB
*/
app.service('MainService', function($http, $q, $timeout) {

	var factory = {


	};
	return factory;
});
