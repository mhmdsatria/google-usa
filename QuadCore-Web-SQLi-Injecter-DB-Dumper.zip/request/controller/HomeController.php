<?php
class HomeController extends Controller
{
  function index()
  {

  }
  
}
